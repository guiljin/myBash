#
# ====================================================================
# (c) 2005-2009 Barry A Scott.  All rights reserved.
#
# This software is licensed as described in the file LICENSE.txt,
# which you should have received as part of this distribution.
#
# ====================================================================
#
#
#   setup_backport_probe.py
#
#   loading this module to test for the need to run the backport command
#
try:
    pass
except ValueError as e:
    pass
